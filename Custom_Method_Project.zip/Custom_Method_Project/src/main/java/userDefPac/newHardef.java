package userDefPac;

public class newHardef {

}
